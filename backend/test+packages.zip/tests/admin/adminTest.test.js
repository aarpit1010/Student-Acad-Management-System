const supertest = require("supertest");
const app = require("../../app");
// const Student = require("../../models/Student");
const mongoose = require("mongoose");
const Student = require("../../model/Student");
const Log = require("../../model/log");
const { course_summary, droppedcourses, notifs, attend } = require("../../model/marks");
const viewprof = require("../../model/facultyList");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { studentRegisterValid, studentLoginValid } = require("../../controllers/validation");

const {
    loginStudent,
    initialStudents,
    fakeToken,
    invalidToken,
} = require("../testHelper");


const api = supertest(app);

let student;

// beforeEach(async () => {
//     // await mongoose.connect(
//     //     process.env.DB_CONNECT,
//     //     { useUnifiedTopology: true, 
//     //       useNewUrlParser: true,
//     //       useFindAndModify: false,
//     //       useCreateIndex: true },
//     //     () => console.log("Connected to Testing MongoDB")
//     // ); 
//     student = await loginStudent(initialStudents[0]);

//   });

it('Should save user to database', async () => {
    const res = await api.post('/student/register')
      .send(initialStudents[1])
      .expect(201);
    // done()
  });







  afterAll(() => { 
    mongoose.connection.close()
  })